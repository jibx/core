
package org.jibx.starter;

public class Person {
    public int customerNumber;
    public String firstName;
    public String lastName;
}
