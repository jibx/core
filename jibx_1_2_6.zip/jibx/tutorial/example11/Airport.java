
package example11;

public class Airport
{
    private String code;
    private String name;
    private String location;
}
