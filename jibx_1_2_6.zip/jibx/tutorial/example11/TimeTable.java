
package example11;

import java.util.ArrayList;

public class TimeTable
{
    private ArrayList carriers;
    private ArrayList airports;
    private ArrayList routes;
}
