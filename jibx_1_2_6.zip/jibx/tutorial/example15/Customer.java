
package example15;

public class Customer {
    public int customerNumber;
    public String firstName;
    public String lastName;
    public Address shipAddress;
    public Address billAddress;
    public String phone;
}
