
package example16;

public class Company extends Identity {
    public String name;
    public String taxId;
}
