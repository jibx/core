
package example17;

public class Customer {
    public Identity identity;
    public String street;
    public String city;
    public String state;
    public Integer zip;
    public String phone;
}
