
package example17;

public class Person extends Identity {
    public String firstName;
    public String lastName;
}
