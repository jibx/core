
package example19;

public class Customer {
    private Person person;
    private String street;
    private String city;
    private String state;
    private Integer zip;
    private String phone;
    public void setZip(Integer zip) {
        this.zip = zip;
    }
}
