
package example20;

public class Customer {
    private int customerNumber;
    private String firstName;
    private String lastName;
    private String street;
    private String city;
    private String state;
    private Integer zip;
    private int total;
    private int[] orders;
}
