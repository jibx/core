
package example22;

public class Person {
    private String firstName;
    private String lastName;
    private int customerNumber;
}
