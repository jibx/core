
package example8;

import java.util.ArrayList;
import java.util.LinkedList;

public class TimeTable
{
    private ArrayList carriers;
    private LinkedList airports;
    private String[] notes;
}
