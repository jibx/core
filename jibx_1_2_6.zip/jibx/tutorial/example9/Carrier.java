
package example9;

public class Carrier
{
    private String code;
    private String name;
    private String url;
    private int rating;
}
