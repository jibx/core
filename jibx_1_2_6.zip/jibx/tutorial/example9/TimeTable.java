
package example9;

import java.util.LinkedList;
import java.util.List;

public class TimeTable
{
    private List children;
    
    private static List listFactory() {
      return new LinkedList();
    }
}
